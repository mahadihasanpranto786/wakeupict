<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ContactUs extends Model
{
    //
    protected $guarded = [];
}
