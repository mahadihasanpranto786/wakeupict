@extends('backend.theme.clasic.admin_layouts.admin-master')
@section('title')
    Create National Work
@endsection
{{-- menu active start --}}

@section('apparance', 'menu-open')

@section('apparance_active', 'active')

@section('home_page', 'menu-open')

@section('menu_active_home', 'active bg-info')

@section('national_active', 'active')
{{-- menu active end --}}

@section('maincontant')
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">National Work</div>
                <form action="{{ route('store-national-work') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="card-body">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <a type="button" data-toggle="modal" data-target="#development_title"
                                style="float: right; border-radius: 3px;" class="btn-success text-white">Preview</a>
                            <input type="text" name="title" id="title" class="form-control" placeholder="Title"
                                value="{{ old('title') }}" data-validation='required'>
                            @error('title')
                                <span class="text-theme-6">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="blog_id">Select Blog</label>
                            <a type="button" data-toggle="modal" data-target="#one_blog"
                                style="float: right; border-radius: 3px;" class="btn-success text-white">Preview</a>
                            <select name="blog_id" data-validation='required' class="form-control select2"
                                style="width: 100%;">
                                <option label="Choose one blog" selected disabled>Select One</option>
                                @foreach ($blogs as $blog)
                                    <option value="{{ $blog->id }}"
                                        {{ collect(old('blog_id'))->contains($blog->id) ? 'selected' : '' }}>
                                        {{ $blog->blog_title }}</option>
                                @endforeach
                            </select>
                            @error('blog_id')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>



                        <div class="form-group">
                            <label for="logo">Select Logo</label>
                            <a type="button" data-toggle="modal" data-target="#development_logo"
                                style="float: right; border-radius: 3px;" class="btn-success text-white">Preview</a>
                            <select name="logo" data-validation='required' class="form-control select2"
                                style="width: 100%;">
                                <option label="Choose Logo" selected disabled>Select One</option>
                                @foreach ($icons as $icon)
                                    <option value="{{ $icon->icon }}" data-icon="{{ $icon->icon }}"
                                        {{ collect(old('logo'))->contains($icon->icon) ? 'selected' : '' }}>
                                        {{ $icon->icon }}
                                    </option>
                                @endforeach
                            </select>
                            @error('logo')
                                <span class="text-theme-6">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="inputImg">Upload Image</label>
                            <a type="button" data-toggle="modal" data-target="#development_image"
                                style="float: right; border-radius: 3px;" class="btn-success text-white">Preview</a>

                            <input type="file" class="form-control" name="image" id="inputImg"
                                data-validation='required' onchange="preview()" placeholder="image"
                                value="{{ old('image') }}">

                            @error('image')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <div>
                            <span>
                                <img src="" id="reviewImg">
                            </span>
                        </div>


                        <div class="form-group">
                            <label for="image_alt">Image alt</label>
                            <input type="text" name="image_alt" id="image_alt" class="form-control"
                                placeholder="Enter Image Alt" value="{{ old('image_alt') }}" data-validation='required'>
                            @error('image_alt')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>


                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea type="text" name="description" class="form-control textarea" cols="30" rows="3">{{ old('description') }}</textarea>
                            @error('description')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <!-- /.card-body -->

                        <div class="pt-2">
                            <button type="submit" class="btn btn-primary btn-block">
                                Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        @include('backend/theme/clasic/include/modal_photos/modal')
    </div>
    <script>
        function preview() {
            // const preview = document.querySelector('#imgThambnail');
            const file = document.querySelector('#inputImg').files[0];
            const reader = new FileReader();

            reader.addEventListener("load", function(e) {
                // convert image file to base64 string
                // preview.src = reader.result;
                $('#reviewImg').attr('src', e.target.result).width(250).height(180);

            }, false);

            if (file) {
                reader.readAsDataURL(file);
                document.getElementById("reviewImg").style.cssText = `
                            border: 2px solid gray;
                            padding: 20px;
                            `;
            }
        }
    </script>
@endsection
